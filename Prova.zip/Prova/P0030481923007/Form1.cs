﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030481923007
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] Vetor = new double[7,4];
            double Faturamento;
            string Auxiliar = "";
            double TotalGeral = 0;

            for (var y = 0; y < 7; y++)
            {
                Faturamento = 0;

                for (var x = 0; x < 4; x++)
                {
                    Auxiliar = Interaction.InputBox("Digite a Venda da Semana " + (x + 1),
                    "Entrada de Vendas Semanal");
                    if (double.TryParse(Auxiliar, out Vetor[y, x]))
                    { 
                            Faturamento = Vetor[y, x] + Faturamento;
                            TotalGeral = Faturamento + TotalGeral;
                    }
                    else
                    {
                        y = y + 6;
                        ListBox.Items.Add("");
                        Close();
                    }
                    ListBox.Items.Add("Mês " + (y+1) + " Semana: " + (x+1) + " R$ " + Vetor[y,x].ToString("N2"));
                }
                ListBox.Items.Add(">> Total do mês: " + ( y + 1 ) + " R$ " + Faturamento.ToString("N2"));
            }
            ListBox.Items.Add(">> Total Geral: " + " R$ " + TotalGeral.ToString("N2"));
        }
    }
}
